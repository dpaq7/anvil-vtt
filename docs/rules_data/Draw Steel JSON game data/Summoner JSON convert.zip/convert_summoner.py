#!/usr/bin/env python3
"""
Summoner PDF to JSON Converter
Converts MCDM Summoner v1.0 OCR text files to structured JSON
matching draw-steel-consolidated.json format.

Usage: python convert_summoner.py <input_dir> <output_file>
"""

import json
import re
import os
import sys
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field, asdict

# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class Stats:
    size: str = ""
    speed: int = 0
    stamina: int = 0
    stability: int = 0
    free_strike: int = 0

@dataclass
class Characteristics:
    might: int = 0
    agility: int = 0
    reason: int = 0
    intuition: int = 0
    presence: int = 0

@dataclass
class PowerRollTier:
    tier1: str = ""
    tier2: str = ""
    tier3: str = ""
    roll: str = ""

@dataclass
class Minion:
    name: str = ""
    minion_type: str = ""  # Signature Minion, Minion
    role: str = ""  # Brute, Controller, Artillery, etc
    keywords: list = field(default_factory=list)
    essence_cost: str = ""
    essence_amount: int = 0
    summon_count: int = 1
    stats: Stats = field(default_factory=Stats)
    characteristics: Characteristics = field(default_factory=Characteristics)
    immunity: str = ""
    weakness: str = ""
    movement: str = ""
    free_strike_damage_type: str = ""
    traits: list = field(default_factory=list)
    signature_ability: dict = field(default_factory=dict)
    flavor: str = ""
    portfolio: str = ""

@dataclass 
class Ability:
    name: str = ""
    cost: str = ""
    essence_cost: int = 0
    flavor: str = ""
    keywords: list = field(default_factory=list)
    usage: str = ""
    distance: str = ""
    target: str = ""
    effects: list = field(default_factory=list)
    ability_type: str = ""

@dataclass
class ClassFeature:
    name: str = ""
    level: int = 1
    description: str = ""
    feature_type: str = ""
    circle: str = ""  # For circle-specific features

@dataclass
class Trinket:
    name: str = ""
    echelon: int = 1
    keywords: list = field(default_factory=list)
    item_prerequisite: str = ""
    project_source: str = ""
    project_roll: str = ""
    project_goal: int = 0
    effect: str = ""
    special: str = ""
    flavor: str = ""

# =============================================================================
# Parsing Functions
# =============================================================================

def parse_stat_value(text: str) -> int:
    """Extract numeric value, handling +/- prefixes"""
    match = re.search(r'([+-]?\d+)', text)
    return int(match.group(1)) if match else 0

def parse_characteristics(line: str) -> Characteristics:
    """Parse characteristic line like: Might +2 Agility 0 Reason -1 Intuition -1 Presence -1"""
    chars = Characteristics()
    
    patterns = {
        'might': r'Might\s*([+-]?\d+)',
        'agility': r'Agility\s*([+-]?\d+)',
        'reason': r'Reason\s*([+-]?\d+)',
        'intuition': r'Intuition\s*([+-]?\d+)',
        'presence': r'Presence\s*([+-]?\d+)'
    }
    
    for attr, pattern in patterns.items():
        match = re.search(pattern, line, re.IGNORECASE)
        if match:
            setattr(chars, attr, int(match.group(1)))
    
    return chars

def parse_stats_line(lines: list, start_idx: int) -> tuple[Stats, int]:
    """Parse the stat block table format"""
    stats = Stats()
    idx = start_idx
    
    # Look for Size/Speed/Stamina/Stability/Free Strike pattern
    combined = ' '.join(lines[idx:idx+5])
    
    # Size pattern (1S, 1M, 1L, 1T, 2, etc)
    size_match = re.search(r'(\d[SMLT]?)\s*Size', combined)
    if size_match:
        stats.size = size_match.group(1)
    
    # Speed
    speed_match = re.search(r'(\d+)\s*Speed', combined)
    if speed_match:
        stats.speed = int(speed_match.group(1))
    
    # Stamina (may have format like "5 | 5" for stamina/pool)
    stamina_match = re.search(r'(\d+)(?:\s*\|\s*\d+)?\s*Stamina', combined)
    if stamina_match:
        stats.stamina = int(stamina_match.group(1))
    
    # Stability
    stability_match = re.search(r'(\d+)\s*Stability', combined)
    if stability_match:
        stats.stability = int(stability_match.group(1))
    
    # Free Strike
    fs_match = re.search(r'(\d+)\s*Free\s*Strike', combined)
    if fs_match:
        stats.free_strike = int(fs_match.group(1))
    
    return stats, idx + 3

def parse_minion_block(text: str, portfolio: str) -> Optional[Minion]:
    """Parse a complete minion stat block from OCR text"""
    minion = Minion()
    minion.portfolio = portfolio
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    
    if not lines:
        return None
    
    # Find minion header line (Name + Type + Role)
    # Pattern: "Ensnarer Signature Minion Brute" or "Demon Lord's Aspect Champion"
    header_pattern = r'^(.+?)\s+(Signature\s+Minion|Minion|Champion)\s*(\w*)$'
    
    for i, line in enumerate(lines):
        header_match = re.match(header_pattern, line, re.IGNORECASE)
        if header_match:
            minion.name = header_match.group(1).strip()
            minion.minion_type = header_match.group(2).strip()
            minion.role = header_match.group(3).strip() if header_match.group(3) else "Champion"
            break
    
    if not minion.name:
        return None
    
    # Parse keywords and essence cost line
    # Patterns: "Abyssal, Demon 1 essence per minion summoned"
    #           "Abyssal, Demon 3 essence for two minions"
    #           "Abyssal, Demon 9 essence for one champion"
    for line in lines:
        essence_match = re.search(r'(\d+)\s*essence\s*(per\s*minion|for\s*(one|two|three|four|five|six)\s*(?:minions?|champion))', line, re.IGNORECASE)
        if essence_match:
            minion.essence_amount = int(essence_match.group(1))
            minion.essence_cost = line.split(str(minion.essence_amount))[1].strip() if str(minion.essence_amount) in line else ""
            
            # Extract keywords before essence cost
            keyword_part = line.split(str(minion.essence_amount))[0] if str(minion.essence_amount) in line else ""
            minion.keywords = [k.strip() for k in keyword_part.split(',') if k.strip()]
            
            # Parse summon count
            count_match = re.search(r'for\s*(one|two|three|four|five|six)\s*(?:minions?|champion)', line, re.IGNORECASE)
            if count_match:
                word_to_num = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6}
                count_word = count_match.group(1).lower()
                minion.summon_count = word_to_num.get(count_word, 1)
            else:
                minion.summon_count = 1
            break
    
    # Parse stats
    full_text = '\n'.join(lines)
    
    # Size
    size_match = re.search(r'¢?\s*(\d[SMLT]?)\s*Size', full_text)
    if size_match:
        minion.stats.size = size_match.group(1)
    
    # Speed  
    speed_match = re.search(r'(\d+)\s*Speed', full_text)
    if speed_match:
        minion.stats.speed = int(speed_match.group(1))
    
    # Stamina
    stamina_match = re.search(r'(\d+)(?:\s*\|\s*\d+)?\s*Stamina', full_text)
    if stamina_match:
        minion.stats.stamina = int(stamina_match.group(1))
    
    # Stability
    stability_match = re.search(r'(\d+)\s*Stability', full_text)
    if stability_match:
        minion.stats.stability = int(stability_match.group(1))
    
    # Free Strike value
    fs_match = re.search(r'(\d+)\s*Free\s*Strike', full_text)
    if fs_match:
        minion.stats.free_strike = int(fs_match.group(1))
    
    # Parse immunity/weakness
    immunity_match = re.search(r'Immunity:\s*([^W\n]+?)(?:\s*Weakness|$)', full_text)
    if immunity_match:
        imm = immunity_match.group(1).strip().rstrip(',')
        minion.immunity = imm if imm and imm != '—' else ""
    
    weakness_match = re.search(r'Weakness:\s*([^\n]+?)(?:\n|Movement|$)', full_text)
    if weakness_match:
        weak = weakness_match.group(1).strip()
        minion.weakness = weak if weak and weak != '—' else ""
    
    # Movement and free strike damage type
    movement_match = re.search(r'Movement:\s*([^\n]+?)(?:\s*Free\s*Strike|\n|$)', full_text)
    if movement_match:
        mov = movement_match.group(1).strip()
        # Clean up the movement value
        if 'Free Strike' in mov:
            mov = mov.split('Free Strike')[0].strip()
        minion.movement = mov if mov and mov != '—' else ""
    
    fs_type_match = re.search(r'Free\s*Strike\s*Damage\s*Type:\s*([^\n]+)', full_text)
    if fs_type_match:
        fst = fs_type_match.group(1).strip()
        minion.free_strike_damage_type = fst if fst and fst != '—' else ""
    
    # Parse characteristics
    for line in lines:
        if 'Might' in line and 'Agility' in line:
            minion.characteristics = parse_characteristics(line)
            break
    
    # Parse traits - look for named trait patterns
    # Traits are typically formatted as "Trait Name\nDescription" after the characteristics line
    
    # Find the characteristics line position
    char_pos = full_text.find('Presence')
    if char_pos == -1:
        char_pos = 0
    
    # Get text after characteristics
    traits_section = full_text[char_pos:]
    
    # Common trait name patterns (capitalized words followed by description)
    # Skip stats and keywords we already parsed
    skip_patterns = ['Size', 'Speed', 'Stamina', 'Stability', 'Free Strike', 
                     'Immunity', 'Weakness', 'Movement', 'Might', 'Agility', 
                     'Reason', 'Intuition', 'Presence', 'Abyssal', 'Demon',
                     'Undead', 'Fey', 'Elemental', 'essence']
    
    # Find trait blocks by looking for capitalized headers
    trait_lines = traits_section.split('\n')
    current_trait_name = None
    current_trait_desc = []
    
    for line in trait_lines:
        line = line.strip()
        if not line or line.startswith('¢'):
            continue
            
        # Check if this looks like a trait name (starts with capital, short)
        if (re.match(r'^[A-Z][a-z]+(?:\s+[A-Z]?[a-z]+)*$', line) and 
            len(line) < 40 and
            not any(skip in line for skip in skip_patterns) and
            line not in [minion.name]):
            
            # Save previous trait
            if current_trait_name and current_trait_desc:
                desc = ' '.join(current_trait_desc).strip().rstrip('¢').strip()
                # Check if this is a signature ability
                if 'Signature Ability' in desc or '2d10' in desc:
                    minion.signature_ability = parse_signature_ability(f"{current_trait_name}\n{desc}")
                elif desc:  # Only add if there's actual description
                    minion.traits.append({
                        'name': current_trait_name,
                        'description': desc
                    })
            
            current_trait_name = line
            current_trait_desc = []
        elif current_trait_name:
            # Skip if this looks like another minion's header
            if re.match(r'^[A-Z][a-z]+\s+(Signature\s+)?Minion', line):
                break
            current_trait_desc.append(line)
    
    # Save last trait
    if current_trait_name and current_trait_desc:
        desc = ' '.join(current_trait_desc).strip().rstrip('¢').strip()
        if 'Signature Ability' in desc or '2d10' in desc:
            minion.signature_ability = parse_signature_ability(f"{current_trait_name}\n{desc}")
        elif desc:  # Only add if there's actual description
            minion.traits.append({
                'name': current_trait_name,
                'description': desc
            })
    
    return minion

def parse_signature_ability(text: str) -> dict:
    """Parse a signature ability block"""
    ability = {
        'name': '',
        'roll': '',
        'keywords': [],
        'usage': '',
        'distance': '',
        'target': '',
        'tiers': {}
    }
    
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    
    # First line is usually name + roll indicator
    if lines:
        name_match = re.match(r'^(.+?)\s*(?:2d10|Signature)', lines[0])
        if name_match:
            ability['name'] = name_match.group(1).strip()
    
    # Look for keywords line
    keyword_line = re.search(r'((?:Magic|Melee|Ranged|Strike|Area|Weapon|Attack)(?:,\s*(?:Magic|Melee|Ranged|Strike|Area|Weapon|Attack))*)', text, re.IGNORECASE)
    if keyword_line:
        ability['keywords'] = [k.strip() for k in keyword_line.group(1).split(',')]
    
    # Look for action type
    if 'Main action' in text:
        ability['usage'] = 'Main action'
    elif 'Maneuver' in text:
        ability['usage'] = 'Maneuver'
    elif 'Free triggered' in text:
        ability['usage'] = 'Free triggered'
    
    # Distance and target
    dist_match = re.search(r'((?:Melee|Ranged)\s*\d+[^\n]*)', text)
    if dist_match:
        ability['distance'] = dist_match.group(1).strip()
    
    target_match = re.search(r'(?:One|Two|Each|All)\s+(?:creature|enemy|ally|object)[^\n]*', text)
    if target_match:
        ability['target'] = target_match.group(0).strip()
    
    # Parse power roll tiers
    # Pattern: "4 damage; p<w twisted (save ends)"
    tier_patterns = [
        (r'á\s*(.+?)(?=é|$)', 'tier1'),
        (r'é\s*(.+?)(?=í|$)', 'tier2'),  
        (r'í\s*(.+?)(?=\n|Effect|$)', 'tier3')
    ]
    
    for pattern, tier_name in tier_patterns:
        match = re.search(pattern, text, re.DOTALL)
        if match:
            ability['tiers'][tier_name] = match.group(1).strip()
    
    # Also try numeric tier format
    numeric_tiers = re.findall(r'(\d+)\s*damage[;\s]*(.+?)(?=\d+\s*damage|Effect|$)', text, re.DOTALL)
    if numeric_tiers and not ability['tiers']:
        for i, (dmg, effect) in enumerate(numeric_tiers[:3]):
            tier_name = f'tier{i+1}'
            ability['tiers'][tier_name] = f"{dmg} damage; {effect.strip()}"
    
    # Effect
    effect_match = re.search(r'Effect:\s*(.+?)(?=Special:|$)', text, re.DOTALL)
    if effect_match:
        ability['effect'] = effect_match.group(1).strip()
    
    return ability

def parse_heroic_ability(text: str) -> Optional[Ability]:
    """Parse a heroic ability block"""
    ability = Ability()
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    
    if not lines:
        return None
    
    # First line is name + cost
    # Pattern: "Abyssal Gate (5 Essence)" or just "Summoner Strike"
    name_match = re.match(r'^(.+?)\s*\((\d+)\s*Essence\)', lines[0])
    if name_match:
        ability.name = name_match.group(1).strip()
        ability.essence_cost = int(name_match.group(2))
        ability.cost = f"{ability.essence_cost} Essence"
    else:
        # Check for pattern without parentheses
        simple_match = re.match(r'^([A-Za-z][A-Za-z\s\'\-!]+)$', lines[0])
        if simple_match:
            ability.name = simple_match.group(1).strip()
        else:
            return None
    
    full_text = '\n'.join(lines)
    
    # Extract flavor text (typically in italics, appears before keywords)
    # Look for text between name line and keywords line
    keyword_line_match = re.search(r'((?:Area|Magic|Melee|Ranged|Strike|Weapon|Champion)(?:,?\s*(?:Area|Magic|Melee|Ranged|Strike|Weapon|Champion))*)\s+(Main action|Maneuver|Free triggered|Free maneuver)', full_text)
    if keyword_line_match:
        start_idx = full_text.find(keyword_line_match.group(0))
        potential_flavor = full_text[len(lines[0]):start_idx].strip()
        if potential_flavor and len(potential_flavor) > 10 and not any(kw in potential_flavor for kw in ['Power Roll', 'Melee', 'Ranged']):
            ability.flavor = potential_flavor.replace('\n', ' ').strip('"').strip()
    
    # Keywords and action type
    if keyword_line_match:
        keywords_str = keyword_line_match.group(1)
        ability.keywords = [k.strip() for k in re.split(r',\s*', keywords_str)]
        ability.usage = keyword_line_match.group(2)
    
    # Distance - look for patterns like "Melee 1", "Ranged 5", "3 burst", "Summoner's Range"
    dist_patterns = [
        r'(Melee\s+\d+)',
        r'(Ranged\s+\d+)',
        r'(Summoner\'s Range)',
        r'(\d+\s+burst)',
        r'(\d+\s+cube\s+within\s+\d+)',
        r'(Self)',
    ]
    for pattern in dist_patterns:
        dist_match = re.search(pattern, full_text)
        if dist_match:
            ability.distance = dist_match.group(1).strip()
            break
    
    # Target
    target_patterns = [
        r'(One\s+creature(?:\s+or\s+object)?)',
        r'(Two\s+creature(?:s)?(?:\s+or\s+object(?:s)?)?)',
        r'(Each\s+(?:enemy|ally|creature)\s+in\s+the\s+area)',
        r'(All\s+Allies)',
        r'(Self(?:\s+and\s+.+)?)',
        r'(Special)',
    ]
    for pattern in target_patterns:
        target_match = re.search(pattern, full_text, re.IGNORECASE)
        if target_match:
            ability.target = target_match.group(1).strip()
            break
    
    # Power roll tiers - using á é í symbols
    effects = []
    tier_data = {}
    
    # Find power roll line
    roll_match = re.search(r'Power Roll \+ (\w+):', full_text)
    
    # Parse tiers with special symbols
    tier1_match = re.search(r'á\s*(.+?)(?=\s*é|\n\n|Effect)', full_text, re.DOTALL)
    tier2_match = re.search(r'é\s*(.+?)(?=\s*í|\n\n|Effect)', full_text, re.DOTALL)
    tier3_match = re.search(r'í\s*(.+?)(?=\n\n|Effect|Special|$)', full_text, re.DOTALL)
    
    if tier1_match:
        tier_data['tier1'] = tier1_match.group(1).strip().replace('\n', ' ')
    if tier2_match:
        tier_data['tier2'] = tier2_match.group(1).strip().replace('\n', ' ')
    if tier3_match:
        tier_data['tier3'] = tier3_match.group(1).strip().replace('\n', ' ')
    
    if tier_data:
        roll_str = f"Power Roll + {roll_match.group(1)}" if roll_match else "Power Roll"
        effects.append({
            'roll': roll_str,
            **tier_data
        })
    
    # Effect text
    effect_match = re.search(r'Effect:\s*(.+?)(?=Special:|Spend|¥|\Z)', full_text, re.DOTALL)
    if effect_match:
        effect_text = effect_match.group(1).strip().replace('\n', ' ')
        if effect_text:
            effects.append({
                'name': 'Effect',
                'effect': effect_text
            })
    
    # Special text
    special_match = re.search(r'Special:\s*(.+?)(?=\n\n|\Z)', full_text, re.DOTALL)
    if special_match:
        special_text = special_match.group(1).strip().replace('\n', ' ')
        if special_text:
            effects.append({
                'name': 'Special',
                'effect': special_text
            })
    
    # Charge effects (bullets with ¥)
    charge_effects = re.findall(r'¥\s*(\d+\s*charge[s]?:\s*.+?)(?=¥|\Z)', full_text, re.DOTALL)
    for charge in charge_effects:
        effects.append({
            'name': 'Charge Option',
            'effect': charge.strip().replace('\n', ' ')
        })
    
    ability.effects = effects
    
    return ability

def parse_trinket(text: str, echelon: int) -> Optional[Trinket]:
    """Parse a trinket/reward block"""
    trinket = Trinket()
    trinket.echelon = echelon
    
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    if not lines:
        return None
    
    # First non-empty line should be the name
    trinket.name = lines[0]
    
    # Skip if name looks like a header/section
    if any(x in trinket.name.lower() for x in ['echelon', 'trinket', 'following', 'draw steel']):
        return None
    
    full_text = '\n'.join(lines)
    
    # Keywords - must be present
    keyword_match = re.search(r'Keywords:\s*([^\n]+)', full_text)
    if not keyword_match:
        return None
    trinket.keywords = [k.strip() for k in keyword_match.group(1).split(',')]
    
    # Item Prerequisite
    prereq_match = re.search(r'Item Prerequisite:\s*(.+?)(?=\nProject|$)', full_text, re.DOTALL)
    if prereq_match:
        trinket.item_prerequisite = prereq_match.group(1).strip().replace('\n', ' ')
    
    # Project Source
    source_match = re.search(r'Project Source:\s*(.+?)(?=\n|$)', full_text)
    if source_match:
        trinket.project_source = source_match.group(1).strip()
    
    # Project Roll
    roll_match = re.search(r'Project Roll Characteristic:\s*(.+?)(?=\n|$)', full_text)
    if roll_match:
        trinket.project_roll = roll_match.group(1).strip()
    
    # Project Goal - must be present and > 0
    goal_match = re.search(r'Project Goal:\s*(\d+)', full_text)
    if not goal_match:
        return None
    trinket.project_goal = int(goal_match.group(1))
    
    # Extract flavor (text between name and Keywords)
    name_end = full_text.find(trinket.name) + len(trinket.name)
    keyword_start = full_text.find('Keywords:')
    if keyword_start > name_end:
        flavor = full_text[name_end:keyword_start].strip()
        if flavor:
            trinket.flavor = flavor.replace('\n', ' ')
    
    # Effect
    effect_match = re.search(r'Effect:\s*(.+?)(?=Special:|$)', full_text, re.DOTALL)
    if effect_match:
        trinket.effect = effect_match.group(1).strip().replace('\n', ' ')
    
    # Special
    special_match = re.search(r'Special:\s*(.+?)$', full_text, re.DOTALL)
    if special_match:
        trinket.special = special_match.group(1).strip().replace('\n', ' ')
    
    return trinket

def parse_class_feature(text: str) -> Optional[ClassFeature]:
    """Parse a class feature block"""
    feature = ClassFeature()
    
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    if not lines:
        return None
    
    feature.name = lines[0]
    feature.description = ' '.join(lines[1:]) if len(lines) > 1 else ""
    
    return feature

# =============================================================================
# Portfolio Detection
# =============================================================================

PORTFOLIO_PATTERNS = {
    # Order matters - more specific patterns first
    'fey': [r'\bFey\b', r'Circle of Spring', r'feybright', r'\bArcadia\b', r'\bpixie\b', r'\bsprite\b', r'\bnixie\b'],
    'undead': [r'\bUndead\b', r'Circle of Graves', r'necromancer', r'Necropolitan'],
    'elemental': [r'\bElemental\b', r'Circle of Storms', r'storm caster', r'Quintessence'],
    'demon': [r'\bAbyssal\b', r'\bDemon\s', r'Circle of Blight', r'demonologist'],  # Note \bDemon\s to avoid matching "demons"
}

def detect_portfolio(text: str) -> str:
    """Detect which portfolio a section belongs to based on keywords"""
    import re
    
    # Check for explicit portfolio headers first
    if re.search(r'Fey Portfolio', text, re.IGNORECASE):
        return 'fey'
    if re.search(r'Undead Portfolio', text, re.IGNORECASE):
        return 'undead'
    if re.search(r'Elemental Portfolio', text, re.IGNORECASE):
        return 'elemental'
    if re.search(r'Demon Portfolio', text, re.IGNORECASE):
        return 'demon'
    
    # Fall back to pattern matching
    for portfolio, patterns in PORTFOLIO_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return portfolio
    
    return 'general'

# =============================================================================
# Main Processing
# =============================================================================

def slugify(text: str) -> str:
    """Convert text to URL-safe slug"""
    text = text.lower()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_]+', '_', text)
    return text.strip('_')

def minion_to_json_item(minion: Minion) -> dict:
    """Convert Minion dataclass to JSON item format"""
    slug = slugify(minion.name)
    essence_str = f"{minion.essence_amount}essence" if minion.essence_amount else "signature"
    
    # Handle champion naming
    if minion.minion_type.lower() == 'champion':
        essence_str = "9essence_champion"
    
    item = {
        "_id": f"heroes/summoner/minions/{minion.portfolio}/{essence_str}/{slug}",
        "_category": "heroes",
        "_filename": slug,
        "_subcategory": f"summoner/minions/{minion.portfolio}/{essence_str}",
        "type": "minion",
        "name": minion.name,
        "minion_type": minion.minion_type,
        "role": minion.role,
        "portfolio": minion.portfolio,
        "essence_cost": minion.essence_amount,
        "summon_count": minion.summon_count,
        "keywords": minion.keywords,
        "stats": {
            "size": minion.stats.size,
            "speed": minion.stats.speed,
            "stamina": minion.stats.stamina,
            "stability": minion.stats.stability,
            "free_strike": minion.stats.free_strike
        },
        "characteristics": {
            "might": minion.characteristics.might,
            "agility": minion.characteristics.agility,
            "reason": minion.characteristics.reason,
            "intuition": minion.characteristics.intuition,
            "presence": minion.characteristics.presence
        },
        "immunity": minion.immunity,
        "weakness": minion.weakness,
        "movement": minion.movement,
        "free_strike_damage_type": minion.free_strike_damage_type,
        "traits": minion.traits,
        "metadata": {
            "source": "mcdm.summoner.v1",
            "class": "summoner",
            "portfolio": minion.portfolio,
            "essence_cost": minion.essence_amount,
            "role": minion.role,
            "minion_type": minion.minion_type
        }
    }
    
    if minion.signature_ability:
        item["signature_ability"] = minion.signature_ability
    
    if minion.flavor:
        item["flavor"] = minion.flavor
    
    return item

def is_valid_minion(minion: Minion) -> bool:
    """Check if a parsed minion is actually valid and not a false positive"""
    # Must have a name
    if not minion.name or len(minion.name) < 2:
        return False
    
    # Name shouldn't be generic text
    invalid_names = [
        'Portfolio', 'Essence', 'New', 'Level', 'Feature', 'John', 
        'Draw Steel', 'Minion', 'Champion', 'The', 'Effect', 'Trinket'
    ]
    for invalid in invalid_names:
        if minion.name == invalid or minion.name.startswith(invalid + ' '):
            return False
    
    # Must have essence cost > 0 or be a valid signature minion
    if minion.essence_amount == 0 and 'Signature' not in minion.minion_type:
        return False
    
    # Signature minions should have essence = 1
    if 'Signature' in minion.minion_type and minion.essence_amount == 0:
        minion.essence_amount = 1  # Fix missing essence
    
    # Champions should have essence = 9
    if minion.minion_type.lower() == 'champion' and minion.essence_amount == 0:
        minion.essence_amount = 9  # Fix missing essence
    
    # Must have some stats
    if minion.stats.speed == 0 and minion.stats.stamina == 0 and minion.stats.free_strike == 0:
        return False
    
    # Must have keywords (all minions have at least one keyword)
    if not minion.keywords:
        return False
    
    return True

def ability_to_json_item(ability: Ability, level: int = 1) -> dict:
    """Convert Ability dataclass to JSON item format"""
    slug = slugify(ability.name)
    essence_str = f"{ability.essence_cost}essence" if ability.essence_cost else "feature"
    
    return {
        "_id": f"heroes/summoner/abilities/{essence_str}/{slug}",
        "_category": "heroes",
        "_filename": slug,
        "_subcategory": f"summoner/abilities/{essence_str}",
        "type": "feature",
        "feature_type": "ability",
        "name": ability.name,
        "cost": ability.cost,
        "essence_cost": ability.essence_cost,
        "flavor": ability.flavor,
        "keywords": ability.keywords,
        "usage": ability.usage,
        "distance": ability.distance,
        "target": ability.target,
        "effects": ability.effects,
        "metadata": {
            "source": "mcdm.summoner.v1",
            "class": "summoner",
            "cost": ability.cost,
            "essence_cost": ability.essence_cost,
            "level": level,
            "feature_type": "ability"
        }
    }

def trinket_to_json_item(trinket: Trinket) -> dict:
    """Convert Trinket dataclass to JSON item format"""
    slug = slugify(trinket.name)
    
    return {
        "_id": f"heroes/summoner/rewards/trinkets/{trinket.echelon}echelon/{slug}",
        "_category": "heroes",
        "_filename": slug,
        "_subcategory": f"summoner/rewards/trinkets/{trinket.echelon}echelon",
        "type": "trinket",
        "name": trinket.name,
        "echelon": trinket.echelon,
        "keywords": trinket.keywords,
        "item_prerequisite": trinket.item_prerequisite,
        "project_source": trinket.project_source,
        "project_roll": trinket.project_roll,
        "project_goal": trinket.project_goal,
        "effect": trinket.effect,
        "special": trinket.special,
        "metadata": {
            "source": "mcdm.summoner.v1",
            "class": "summoner",
            "echelon": trinket.echelon,
            "type": "trinket"
        }
    }

def feature_to_json_item(feature: ClassFeature, level: int = 1, circle: str = "") -> dict:
    """Convert ClassFeature dataclass to JSON item format"""
    slug = slugify(feature.name)
    
    subcategory = f"summoner/features/{level}level"
    if circle:
        subcategory = f"summoner/features/{circle}/{level}level"
    
    return {
        "_id": f"heroes/{subcategory}/{slug}",
        "_category": "heroes",
        "_filename": slug,
        "_subcategory": subcategory,
        "type": "feature",
        "feature_type": "class_feature",
        "name": feature.name,
        "level": level,
        "description": feature.description,
        "circle": circle,
        "metadata": {
            "source": "mcdm.summoner.v1",
            "class": "summoner",
            "level": level,
            "circle": circle,
            "feature_type": "class_feature"
        }
    }

def process_ocr_files(input_dir: str) -> dict:
    """Process all OCR text files and extract structured data"""
    items = []
    input_path = Path(input_dir)
    
    # Read all text files in order
    txt_files = sorted(input_path.glob('*.txt'), key=lambda x: int(x.stem) if x.stem.isdigit() else 0)
    
    all_text = ""
    page_texts = {}
    
    for txt_file in txt_files:
        with open(txt_file, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
            page_num = int(txt_file.stem) if txt_file.stem.isdigit() else 0
            page_texts[page_num] = content
            all_text += f"\n--- PAGE {page_num} ---\n{content}"
    
    current_portfolio = 'general'
    current_echelon = 1
    
    # Split into sections by minion stat blocks
    # Pattern: Name followed by "Signature Minion", "Minion", or "Champion" and role
    minion_pattern = r'([A-Z][a-z]+(?:[\'\s][A-Z]?[a-z]+)*)\s+(Signature\s+Minion|Minion|Champion)\s*(\w+)?'
    
    # Find all minion blocks
    for page_num, page_text in page_texts.items():
        # Detect portfolio for this page
        portfolio = detect_portfolio(page_text)
        if portfolio != 'general':
            current_portfolio = portfolio
        
        # Find minion stat blocks on this page
        matches = list(re.finditer(minion_pattern, page_text))
        
        for i, match in enumerate(matches):
            start = match.start()
            # End at next minion or end of page
            end = matches[i+1].start() if i+1 < len(matches) else len(page_text)
            
            block_text = page_text[start:end]
            minion = parse_minion_block(block_text, current_portfolio)
            
            if minion and minion.name and is_valid_minion(minion):
                items.append(minion_to_json_item(minion))
    
    # Parse heroic abilities - look for "(X Essence)" pattern
    # Ability names are on their own lines before the essence cost
    # Names can start with letters or numbers (e.g., "10,000 Minions")
    ability_header_pattern = r'\n([A-Z0-9][^\n(]+?)\s*\((\d+)\s*Essence\)'
    
    # Process pages that contain heroic abilities 
    # 5-essence: 25-26, 7-essence: 32-33, 9-essence: 39-40, 11-essence: 45-46
    ability_pages = [25, 26, 32, 33, 39, 40, 41, 42, 45, 46]
    
    for page_num in ability_pages:
        if page_num not in page_texts:
            continue
            
        page_text = page_texts[page_num]
        
        # Find ability blocks
        matches = list(re.finditer(ability_header_pattern, page_text))
        
        for i, match in enumerate(matches):
            # Skip if this looks like a minion block
            after_match = page_text[match.end():match.end()+100]
            if 'Signature Minion' in after_match or 'Minion' in after_match.split('\n')[0]:
                continue
                
            start = match.start()
            # Find end - next ability header or significant section break
            end = matches[i+1].start() if i+1 < len(matches) else min(start + 2000, len(page_text))
            
            # Also end at section headers like "X-Level Features"
            section_break = re.search(r'\n\d+(?:st|nd|rd|th)-Level Features', page_text[start:end])
            if section_break:
                end = start + section_break.start()
            
            block = page_text[start:end].strip()
            
            # Skip if too short
            if len(block) < 100:
                continue
                
            ability = parse_heroic_ability(block)
            
            if ability and ability.name and ability.essence_cost > 0:
                # Check we haven't already added this
                existing_names = [item.get('name') for item in items if item.get('type') == 'feature']
                if ability.name not in existing_names:
                    items.append(ability_to_json_item(ability))
    
    # Parse trinkets with better block detection
    # Trinkets appear on pages 47-51 with clear structure
    current_echelon = 1
    
    for page_num in range(47, 52):
        if page_num not in page_texts:
            continue
            
        page_text = page_texts[page_num]
        
        # Track echelon changes
        for match in re.finditer(r'(\d+)(?:st|nd|rd|th)-Echelon\s+Trinket', page_text):
            echelon_pos = match.start()
            current_echelon = int(match.group(1))
        
        # Split text into potential trinket blocks
        # Look for patterns that start a new trinket: capitalized name followed by description then Keywords:
        lines = page_text.split('\n')
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            # Check for echelon marker
            echelon_match = re.match(r'(\d+)(?:st|nd|rd|th)-Echelon\s+Trinket', line)
            if echelon_match:
                current_echelon = int(echelon_match.group(1))
                i += 1
                continue
            
            # Check if this looks like a trinket name (capitalized words, not a section header)
            if (line and 
                re.match(r'^[A-Z][a-z]+(?:[\s\'][A-Z]?[a-z]+)*$', line) and
                len(line) > 5 and len(line) < 50 and
                not any(x in line.lower() for x in ['echelon', 'trinket', 'feature', 'following', 'designed', 'draw steel', 'the summoner'])):
                
                # Collect the block until we hit another trinket name or section
                block_lines = [line]
                j = i + 1
                while j < len(lines) and j < i + 25:
                    next_line = lines[j].strip()
                    
                    # Stop if we hit another potential trinket name or section header
                    if (next_line and 
                        re.match(r'^[A-Z][a-z]+(?:[\s\'][A-Z]?[a-z]+)*$', next_line) and
                        len(next_line) > 5 and len(next_line) < 50 and
                        j > i + 5):  # Must have some content first
                        break
                    
                    if re.match(r'^\d+(?:st|nd|rd|th)-', next_line):
                        break
                        
                    block_lines.append(next_line)
                    j += 1
                
                block = '\n'.join(block_lines)
                
                # Only process if it has Keywords (required for trinkets)
                if 'Keywords:' in block and 'Project Goal:' in block:
                    trinket = parse_trinket(block, current_echelon)
                    if trinket and trinket.name and trinket.project_goal > 0:
                        # Avoid duplicates
                        existing_names = [item.get('name') for item in items if item.get('type') == 'trinket']
                        if trinket.name not in existing_names:
                            items.append(trinket_to_json_item(trinket))
                
                i = j
            else:
                i += 1
    
    # Build final output
    output = {
        "_meta": {
            "description": "MCDM Summoner v1.0 data for Mettle/Anvil development",
            "usage": "LLM-optimized format. Each item has _id, _category, _subcategory for filtering.",
            "source": "MCDM Summoner v1.0 PDF",
            "license": "Draw Steel Creator License",
            "totalItems": len(items),
            "categories": {
                "heroes": len(items)
            }
        },
        "items": items
    }
    
    return output

def main():
    if len(sys.argv) < 3:
        print("Usage: python convert_summoner.py <input_dir> <output_file>")
        print("  input_dir: Directory containing extracted OCR text files")
        print("  output_file: Output JSON file path")
        sys.exit(1)
    
    input_dir = sys.argv[1]
    output_file = sys.argv[2]
    
    print(f"Processing OCR files from: {input_dir}")
    
    result = process_ocr_files(input_dir)
    
    print(f"Extracted {result['_meta']['totalItems']} items")
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    
    print(f"Output written to: {output_file}")

if __name__ == "__main__":
    main()
